
import pandas as pd
import numpy as np
import json
from pprint import pprint
import sys
import os
import time


################ USED TO CREATE SMALL DATASET ####################
def savetoCSV(dest,records=100):
    # save the data
    try:
        with open(dest, "w") as record_file:
            for line in data:
                record_file.write(line)
    except:
        print("An error ocurred when writing to the destination")
        print("Destination: {}".format(dest))
        return False
    
    return True
#################################################################


def savetoJSON(df,orient='records',path=None):
    jsonobject = df.to_json(orient='records')
    if path:
        with open(path, 'w') as outfile:
            outfile.write(json.dumps(jsonobject, indent=2))

    return jsonobject


def main(): 
    records = 1000
    # basepath = "../data/IPIP-FFM-data-8Nov2018"
    basepath = "us_names"
    output_csv = os.path.join(".","us_names.csv")

    column_names = ["state", "sex", "birth_year","name","count"]
    df_final = pd.DataFrame(columns = column_names)
    for file in os.listdir(basepath):
        if file.lower().endswith(".txt"):
            file_path = os.path.join(basepath, file)
            try:
                # df_final.append(pd.read_csv(file_path,sep=','),ignore_index = True)
                tmpDF = pd.read_csv(file_path,sep=',',names=column_names)
            except Exception as e:
                print("Exception: {}".format(e))
                sys.exit(1)
        
            df_final = df_final.append(tmpDF,ignore_index = True)

    df_final = df_final[['name', 'sex', 'birth_year']]

    # save to CSV file
    df_final.to_csv(output_csv,index=False)

    # savetoJSON(goals,orient='records',path=os.path.join(basepath,"ipip-scores.json")
    # pprint(savetoJSON(df,orient='records'))

      
if __name__ == "__main__": 
  
    # calling main function 
    main() 